Toobin music/sfx instructions V0.2

Use the following equates...
Init = $473f
Frame = $4000
Init = $473f
SFX = $4819
Vars = $c594
Vars_End = $c5fc


Load the music driver (musicd.bin) at $4000 (any bank)
Make sure you have reserved space for our variables from Vars to Vars_End

*****************************
First you need to initialize the driver.
To do this do the following...

LD E,0  ;this could be a tune if you want to start one immediately.
CALL Init 
*****************************

PLAYING AND STARTING MUSIC / SFX
--------------------------------

CALL Frame ;once every frame
CALL Init  ;with tune no. in E to start tune (Most of the sfx are done as tunes)
CALL SFX   ;with SFX no. in E to start SFX

TOOBIN2.BIN
-----------
$00 - Music off
$01 - Jurrasic
$02 - Rio Grande
$03 - Black Forest
$04 - Canals of Mars
$05 - NIghtmare
$06 - Title tune


SFX NUMBERS
-----------
$00 - paddle
$01 - bounce off gate
$02 - bounce off other player
$03 - collect can
$04 - collect chest
$05 - Go through green gate
$06 - Go through red gate
$07 - Player loose life
$08 - Player Splash (eg after waterfall)
$09 - Large object splash (eg log falling in)
$0a - fire can
$0b - fire when out of ammo
$0c - collect flower
$0d - collect beachball
$0e - start game bell
$0f - can impact (ie fire can at player or object)
$10 - rock falling
$11 - cast fishing rod
$12 - Indian firing arrow whoosh
$13 - Mine explode
$14 - Shotgun firing (Man firing)
$15 - Tree bend over and coconut falls off (spring sound)
$16 - Lazer fire (eg Lion statues firing)
$17 - Boy skimming stone across water
$18 - Oil bubbling out
$19 - Boomerang throw
$1A - Bifs letters appear (beep for bonus letters appearing at the end of level)
$1B - Penguins jumping out (I gave these a low priority as they repeat quite quickly)
$1C - Player Speedup on rapids (whoosh)
$1D - Waterfall approaching (automatically loop)
      Stop by playing the splash effect when player hits water after waterfall
$1E - Big baddy on screen (eg Alligtor)
