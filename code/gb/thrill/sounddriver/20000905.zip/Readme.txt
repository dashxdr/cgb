Pinball music instructions

Use the following equates...

Init  = $4000
SFX   = $4003
Frame = $4006 

Vars = $c594
Vars_End = $c5ff

Load the music driver (musicd.bin) at $4000

;*****************************
First you need to initialize the driver.
To do this do the following...

LD E,0  ;this could be a tune if you wanted to start one immediately
CALL Init 
;*****************************

To use the driver...

CALL Frame ; once every frame
CALL Init  ;with tune no. in E to start tune
CALL SFX   ; with SFX no. in E to start SFX


;*****************************

TUNE NUMBERS 
------------
00 - Music off
01 - Fun Zone (was Bumper cars)
02 - Multi ball
03 - Hide and Seek (was Flying falcon)
04 - River rapids
05 - Lights out
06 - Nite Time
07 - Thrill Ride

In the sfx driver we can define sfx priorites which I'm certain you'll need to use
However at the moment we have given everything equal weighting

I would reccomend setting all short sounds to a low priority (ball hits etc)
and jingles, special features hit etc to a higher priority.
If you'd like to sort out a complete priority list thats fine,
otherwize we will just take an intellegent guess.

SFX NUMBERS
-----------
Blank      ; $00  ; you can use this to stop other sfx early
ball fire  ; $01
menu move  ; $02
menu -no   ; $03
menuselect ; $04
menu back  ; $05
awardlit   ; $06
combo1     ; $07
combo2     ; $08
combo3     ; $09
combo4     ; $0a
careful    ; $0b
danger     ; $0c
tilt       ; $0d
light on   ; $0e
lit        ; $0f
fantasybit ; $10
lightsbit  ; $11
multiball  ; $12 	     	
multi1     ; $13
scoopout   ; $14 
lockopen   ; $15
superjack  ; $16
balldrain  ; $17
ballsave   ; $18
shootagian ; $19
flipper    ; $1a
bonustone1 ; $1b
bonustone2 ; $1c
bonustone3 ; $1d
bonustone4 ; $1e
bonustone5 ; $1f
bonustone6 ; $20
bonustone7 ; $21
bonustone8 ; $22
finalscore ; $23
charge     ; $24
happytone  ; $25
happybonus ; $26
stophit    ; $27
stophitvic ; $28
popbrief   ; $29
popbrief2  ; $2a	
snack1     ; $2b
snack2     ; $2c
snack3     ; $2d
wildramp   ; $2e
wildjack   ; $2f
wildphoto  ; $30
brassring  ; $31
funtone    ; $32
funstart   ; $33
funlock    ; $34
kisshit    ; $35
kissdown   ; $36	
kissbozo   ; $37       
kissvic    ; $38 
